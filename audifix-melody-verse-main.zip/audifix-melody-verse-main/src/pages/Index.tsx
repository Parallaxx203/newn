
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import AccountTypes from "@/components/AccountTypes";
import MonetizationBreakdown from "@/components/MonetizationBreakdown";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-audifix-black">
      <Navbar />
      <main>
        <Hero />
        <Features />
        <AccountTypes />
        <MonetizationBreakdown />
        <CTA />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
