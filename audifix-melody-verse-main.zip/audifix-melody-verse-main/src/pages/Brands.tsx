
import { useWallet } from "@solana/wallet-adapter-react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Search, Zap, BarChart3 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navbar from "@/components/Navbar";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";

const Brands = () => {
  const { connected } = useWallet();

  // Content for authenticated brands
  const AuthenticatedContent = () => (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-white mb-8">Brand Dashboard</h2>
      
      <Tabs defaultValue="creators" className="w-full">
        <TabsList className="bg-audifix-black border border-audifix-blue/20 mb-8">
          <TabsTrigger value="creators">Find Creators</TabsTrigger>
          <TabsTrigger value="campaigns">My Campaigns</TabsTrigger>
          <TabsTrigger value="analytics">Campaign Analytics</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
        </TabsList>
        
        <TabsContent value="creators" className="text-white">
          <div className="grid gap-6">
            <div className="p-6 rounded-lg border border-audifix-gray/20 bg-audifix-black/40">
              <h3 className="text-xl font-semibold mb-4">Find the Perfect Creator Match</h3>
              <p className="text-gray-300 mb-4">Search through our network of verified creators to find the ideal match for your brand.</p>
              
              <div className="flex items-center gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="text"
                    placeholder="Search by genre, audience, or style..."
                    className="w-full bg-audifix-darkpurple/20 border border-audifix-gray/30 text-white rounded-lg py-3 pl-10 pr-4 focus:outline-none focus:border-audifix-blue"
                  />
                </div>
                <Button className="bg-audifix-blue text-white hover:bg-audifix-blue/80">
                  Search
                </Button>
              </div>
              
              <div className="text-center p-8 border border-dashed border-audifix-gray/30 rounded-lg">
                <p className="text-gray-400">Complete your brand profile to unlock our creator marketplace.</p>
                <Button className="btn-gradient mt-4">Complete Brand Profile</Button>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="campaigns" className="text-white">
          <div className="p-6 rounded-lg border border-audifix-gray/20 bg-audifix-black/40">
            <h3 className="text-xl font-semibold mb-4">Your Campaign Dashboard</h3>
            <p className="text-gray-300 mb-4">Manage your active and past campaigns with creators.</p>
            
            <div className="text-center p-8 border border-dashed border-audifix-gray/30 rounded-lg mb-6">
              <p className="text-gray-400">You haven't created any campaigns yet.</p>
            </div>
            
            <Button className="btn-gradient">Create New Campaign</Button>
          </div>
        </TabsContent>
        
        <TabsContent value="analytics" className="text-white">
          <div className="p-6 rounded-lg border border-audifix-gray/20 bg-audifix-black/40">
            <h3 className="text-xl font-semibold mb-4">Campaign Performance</h3>
            <p className="text-gray-300 mb-4">Track the success of your campaigns with real-time analytics.</p>
            
            <div className="text-center p-8 border border-dashed border-audifix-gray/30 rounded-lg">
              <BarChart3 className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400">Analytics will be available once you've launched your first campaign.</p>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="payments" className="text-white">
          <div className="p-6 rounded-lg border border-audifix-gray/20 bg-audifix-black/40">
            <h3 className="text-xl font-semibold mb-4">Payment History</h3>
            <p className="text-gray-300 mb-4">View your payment history and manage your wallet.</p>
            
            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <div className="p-4 rounded-lg bg-audifix-black/60 border border-audifix-blue/20">
                <p className="text-gray-400 text-sm">Wallet Balance</p>
                <p className="text-gradient text-2xl font-bold">0.00 SOL</p>
              </div>
              <div className="p-4 rounded-lg bg-audifix-black/60 border border-audifix-gray/20">
                <p className="text-gray-400 text-sm">Total Spent</p>
                <p className="text-white text-2xl font-bold">0.00 SOL</p>
              </div>
            </div>
            
            <Button className="bg-audifix-blue text-white hover:bg-audifix-blue/80">
              <Zap className="mr-2 h-4 w-4" /> Add Funds
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );

  // Content for non-authenticated visitors
  const PublicContent = () => (
    <div className="container mx-auto px-4 py-12 md:py-20">
      <div className="max-w-4xl mx-auto text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
          For <span className="text-gradient">Brands</span>
        </h1>
        <p className="text-xl text-gray-300">
          Connect directly with authentic creators and their engaged audiences through transparent partnerships.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-16">
        <div className="p-6 rounded-lg border border-audifix-blue/20 bg-audifix-black/40">
          <h3 className="text-2xl font-bold text-white mb-4">Direct Creator Partnerships</h3>
          <p className="text-gray-300 mb-4">
            Connect with musicians and artists who align perfectly with your brand values.
          </p>
          <ul className="space-y-3 text-gray-300">
            <li className="flex items-start">
              <span className="text-audifix-blue mr-2">•</span>
              Access detailed analytics on creator audiences
            </li>
            <li className="flex items-start">
              <span className="text-audifix-blue mr-2">•</span>
              Smart-match with creators based on your brand goals
            </li>
            <li className="flex items-start">
              <span className="text-audifix-blue mr-2">•</span>
              Transparent pricing with no hidden fees
            </li>
          </ul>
        </div>
        
        <div className="p-6 rounded-lg border border-audifix-purple/20 bg-audifix-black/40">
          <h3 className="text-2xl font-bold text-white mb-4">Music Licensing Simplified</h3>
          <p className="text-gray-300 mb-4">
            License music directly from creators with blockchain-verified rights.
          </p>
          <ul className="space-y-3 text-gray-300">
            <li className="flex items-start">
              <span className="text-audifix-purple mr-2">•</span>
              Clear rights management through smart contracts
            </li>
            <li className="flex items-start">
              <span className="text-audifix-purple mr-2">•</span>
              Discover emerging artists before they go mainstream
            </li>
            <li className="flex items-start">
              <span className="text-audifix-purple mr-2">•</span>
              Custom music creation for your specific needs
            </li>
          </ul>
        </div>
      </div>

      <div className="text-center mb-12">
        <Button className="btn-gradient py-6 px-8 text-lg">
          Sign Up as a Brand <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-audifix-black text-white">
      <Navbar />
      <div className="pt-24">
        {connected ? <AuthenticatedContent /> : <PublicContent />}
      </div>
      <CTA />
      <Footer />
    </div>
  );
};

export default Brands;
