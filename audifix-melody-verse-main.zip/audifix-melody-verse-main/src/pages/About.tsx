
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTA from "@/components/CTA";
import { Button } from "@/components/ui/button";
import { ArrowRight, ShieldCheck, Globe, Users, Coins } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen bg-audifix-black text-white">
      <Navbar />
      
      <div className="pt-24">
        <div className="container mx-auto px-4 py-12 md:py-20">
          {/* Hero Section */}
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              About <span className="text-gradient">Audifyx</span>
            </h1>
            <p className="text-xl text-gray-300">
              We're revolutionizing the music industry by bringing together creators, brands, and fans 
              through blockchain technology and transparent monetization.
            </p>
          </div>
          
          {/* Mission Section */}
          <div className="max-w-4xl mx-auto mb-20">
            <div className="bg-audifix-black/40 border border-audifix-purple/20 rounded-xl p-8 md:p-12">
              <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
              <p className="text-xl text-gray-300 mb-8">
                Audifyx was founded with a simple but powerful mission: to create a more equitable music ecosystem 
                where creators receive fair compensation, brands find authentic partnerships, and fans directly 
                support the artists they love.
              </p>
              <p className="text-xl text-gray-300">
                Through blockchain technology, we're removing intermediaries, increasing transparency, and 
                ensuring that more revenue flows directly to the people creating the music we all enjoy.
              </p>
            </div>
          </div>
          
          {/* Values Section */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold text-center mb-12">Our Values</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-audifix-black/40 border border-audifix-gray/20 rounded-xl p-6 text-center">
                <div className="w-16 h-16 bg-audifix-purple/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ShieldCheck className="h-8 w-8 text-audifix-purple" />
                </div>
                <h3 className="text-xl font-bold mb-3">Transparency</h3>
                <p className="text-gray-300">
                  We believe in complete transparency in all transactions and partnerships.
                </p>
              </div>
              
              <div className="bg-audifix-black/40 border border-audifix-gray/20 rounded-xl p-6 text-center">
                <div className="w-16 h-16 bg-audifix-blue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Coins className="h-8 w-8 text-audifix-blue" />
                </div>
                <h3 className="text-xl font-bold mb-3">Fair Compensation</h3>
                <p className="text-gray-300">
                  Creators deserve to be fairly compensated for their work and contributions.
                </p>
              </div>
              
              <div className="bg-audifix-black/40 border border-audifix-gray/20 rounded-xl p-6 text-center">
                <div className="w-16 h-16 bg-audifix-purple/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-audifix-purple" />
                </div>
                <h3 className="text-xl font-bold mb-3">Community</h3>
                <p className="text-gray-300">
                  We're building a supportive community of creators, brands, and music lovers.
                </p>
              </div>
              
              <div className="bg-audifix-black/40 border border-audifix-gray/20 rounded-xl p-6 text-center">
                <div className="w-16 h-16 bg-audifix-blue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="h-8 w-8 text-audifix-blue" />
                </div>
                <h3 className="text-xl font-bold mb-3">Innovation</h3>
                <p className="text-gray-300">
                  We constantly innovate to stay at the forefront of music technology.
                </p>
              </div>
            </div>
          </div>
          
          {/* Team Section - Placeholder */}
          <div className="max-w-4xl mx-auto mb-20">
            <h2 className="text-3xl font-bold text-center mb-12">Our Team</h2>
            <div className="bg-audifix-black/40 border border-audifix-gray/20 rounded-xl p-8 md:p-12 text-center">
              <p className="text-xl text-gray-300 mb-6">
                We're a diverse team of music lovers, technologists, and industry veterans passionate about 
                creating a better future for the music industry.
              </p>
              <Button className="btn-gradient">
                Join Our Team <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <CTA />
      <Footer />
    </div>
  );
};

export default About;
