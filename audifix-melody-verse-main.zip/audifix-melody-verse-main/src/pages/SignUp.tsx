
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SignUpForm from "@/components/SignUpForm";

const SignUp = () => {
  return (
    <div className="min-h-screen bg-audifix-black text-white">
      <Navbar />
      
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="max-w-md mx-auto bg-audifix-black/40 border border-audifix-purple/20 rounded-xl p-8">
            <SignUpForm />
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default SignUp;
