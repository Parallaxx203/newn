
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navbar from "@/components/Navbar";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";
import { useAuth } from "@/contexts/AuthContext";

const Creators = () => {
  const { user } = useAuth();

  // Content for authenticated creators
  const AuthenticatedContent = () => (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-white mb-8">Creator Dashboard</h2>
      
      <Tabs defaultValue="music" className="w-full">
        <TabsList className="bg-audifix-black border border-audifix-purple/20 mb-8">
          <TabsTrigger value="music">My Music</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="earnings">Earnings</TabsTrigger>
          <TabsTrigger value="brand-deals">Brand Deals</TabsTrigger>
        </TabsList>
        
        <TabsContent value="music" className="text-white">
          <div className="grid gap-6">
            <div className="p-6 rounded-lg border border-audifix-gray/20 bg-audifix-black/40">
              <h3 className="text-xl font-semibold mb-4">Upload Your Music</h3>
              <p className="text-gray-300 mb-4">Share your tracks with the world and start earning from streams, shares, and brand collaborations.</p>
              <Button className="btn-gradient">Upload New Track</Button>
            </div>
            
            <div className="p-6 rounded-lg border border-audifix-gray/20 bg-audifix-black/40">
              <h3 className="text-xl font-semibold mb-4">Your Uploaded Tracks</h3>
              <p className="text-gray-400 italic">No tracks uploaded yet. Get started by uploading your first track.</p>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="analytics" className="text-white">
          <div className="p-6 rounded-lg border border-audifix-gray/20 bg-audifix-black/40">
            <h3 className="text-xl font-semibold mb-4">Performance Analytics</h3>
            <p className="text-gray-300 mb-4">Track your music performance, listener demographics, and engagement metrics.</p>
            <div className="text-center p-8 border border-dashed border-audifix-gray/30 rounded-lg">
              <p className="text-gray-400">Analytics will be available once you've uploaded tracks.</p>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="earnings" className="text-white">
          <div className="p-6 rounded-lg border border-audifix-gray/20 bg-audifix-black/40">
            <h3 className="text-xl font-semibold mb-4">Earnings Dashboard</h3>
            <p className="text-gray-300 mb-4">Monitor your revenue streams and withdraw your earnings instantly.</p>
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <div className="p-4 rounded-lg bg-audifix-black/60 border border-audifix-purple/20">
                <p className="text-gray-400 text-sm">Total Earned</p>
                <p className="text-gradient text-2xl font-bold">0.00 SOL</p>
              </div>
              <div className="p-4 rounded-lg bg-audifix-black/60 border border-audifix-blue/20">
                <p className="text-gray-400 text-sm">Available to Withdraw</p>
                <p className="text-gradient text-2xl font-bold">0.00 SOL</p>
              </div>
              <div className="p-4 rounded-lg bg-audifix-black/60 border border-audifix-gray/20">
                <p className="text-gray-400 text-sm">Pending Earnings</p>
                <p className="text-white text-2xl font-bold">0.00 SOL</p>
              </div>
            </div>
            <Button variant="outline" className="border-audifix-purple text-white" disabled>
              Withdraw Earnings
            </Button>
          </div>
        </TabsContent>
        
        <TabsContent value="brand-deals" className="text-white">
          <div className="p-6 rounded-lg border border-audifix-gray/20 bg-audifix-black/40">
            <h3 className="text-xl font-semibold mb-4">Brand Collaboration Opportunities</h3>
            <p className="text-gray-300 mb-4">Connect with brands looking to partner with creators like you.</p>
            <div className="text-center p-8 border border-dashed border-audifix-gray/30 rounded-lg mb-6">
              <p className="text-gray-400">No brand deals available yet. Complete your profile to attract brand partnerships.</p>
            </div>
            <Button className="btn-gradient">Complete Creator Profile</Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );

  // Content for non-authenticated visitors
  const PublicContent = () => (
    <div className="container mx-auto px-4 py-12 md:py-20">
      <div className="max-w-4xl mx-auto text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
          For <span className="text-gradient">Creators</span>
        </h1>
        <p className="text-xl text-gray-300">
          Unlock new revenue streams and connect directly with your audience through our blockchain-powered platform.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-16">
        <div className="p-6 rounded-lg border border-audifix-purple/20 bg-audifix-black/40">
          <h3 className="text-2xl font-bold text-white mb-4">Earn More from Your Music</h3>
          <p className="text-gray-300 mb-4">
            Get up to $3.00 per 1,000 streams - that's up to 10x more than traditional streaming platforms.
          </p>
          <ul className="space-y-3 text-gray-300">
            <li className="flex items-start">
              <span className="text-audifix-purple mr-2">•</span>
              Direct fan payments and tipping
            </li>
            <li className="flex items-start">
              <span className="text-audifix-purple mr-2">•</span>
              Instant withdrawals to your crypto wallet
            </li>
            <li className="flex items-start">
              <span className="text-audifix-purple mr-2">•</span>
              No middlemen taking large cuts of your earnings
            </li>
          </ul>
        </div>
        
        <div className="p-6 rounded-lg border border-audifix-blue/20 bg-audifix-black/40">
          <h3 className="text-2xl font-bold text-white mb-4">Brand Collaboration Marketplace</h3>
          <p className="text-gray-300 mb-4">
            Connect with brands for sponsored content, music licensing, and more.
          </p>
          <ul className="space-y-3 text-gray-300">
            <li className="flex items-start">
              <span className="text-audifix-blue mr-2">•</span>
              Find brands that align with your artistic vision
            </li>
            <li className="flex items-start">
              <span className="text-audifix-blue mr-2">•</span>
              Negotiate deals directly with transparent terms
            </li>
            <li className="flex items-start">
              <span className="text-audifix-blue mr-2">•</span>
              Secure payment through smart contracts
            </li>
          </ul>
        </div>
      </div>

      <div className="text-center mb-12">
        <Button className="btn-gradient py-6 px-8 text-lg" onClick={() => window.location.href = '/signup'}>
          Sign Up as a Creator <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-audifix-black text-white">
      <Navbar />
      <div className="pt-24">
        {user && user.isAuthenticated ? <AuthenticatedContent /> : <PublicContent />}
      </div>
      <CTA />
      <Footer />
    </div>
  );
};

export default Creators;
