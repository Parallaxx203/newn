
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const AccountTypes = () => {
  const accountTypes = [
    {
      title: "Standard User",
      subtitle: "Listener / Fan",
      description: "Enjoy content and connect with creators",
      features: [
        "Access social features",
        "Profile customization with themes",
        "Join community playlists",
        "Support favorite creators",
      ],
      notIncluded: [
        "No uploads or monetization",
        "No brand campaigns",
      ],
      ctaText: "Sign Up Free",
      color: "gray"
    },
    {
      title: "Creator / Artist",
      subtitle: "For Musicians & Content Creators",
      description: "Monetize your content with instant payouts",
      features: [
        "Upload up to 25 songs",
        "Earn $1.50 per 1,000 views on posts",
        "Earn $3.00 per 1,000 streams",
        "Join brand campaigns",
        "Instant USDC/SOL payouts",
        "All social features included",
      ],
      ctaText: "Become a Creator",
      color: "purple",
      highlighted: true
    },
    {
      title: "Brand / Advertiser",
      subtitle: "For Businesses & Sponsors",
      description: "Connect with creators and run campaigns",
      features: [
        "Campaign creation access",
        "Fund Rewards Wallet ($3,000 min)",
        "Run ads on creator content",
        "Earn 50% of platform fees",
        "Detailed analytics dashboard",
        "Instant withdrawals in USDC/SOL",
      ],
      ctaText: "Start Advertising",
      color: "blue"
    }
  ];

  return (
    <section className="py-20 relative" id="accounts">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-gradient">Account Types</span> & Features
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Choose the right account type for your needs and start participating in the Audifix ecosystem.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {accountTypes.map((account, index) => (
            <div 
              key={index} 
              className={`rounded-xl overflow-hidden relative ${
                account.highlighted 
                  ? 'border-2 border-audifix-purple' 
                  : 'border border-audifix-lightgray/30'
              }`}
            >
              {account.highlighted && (
                <div className="absolute top-0 inset-x-0 h-1 bg-gradient-audifix"></div>
              )}
              
              <div className="p-6 bg-audifix-gray">
                <h3 className="text-2xl font-bold mb-1 text-white">{account.title}</h3>
                <p className="text-gray-400 mb-4">{account.subtitle}</p>
                <p className="text-gray-300 mb-6">{account.description}</p>
                
                <div className="space-y-3 mb-8">
                  {account.features.map((feature, i) => (
                    <div key={i} className="flex items-start">
                      <div className={`rounded-full p-1 mr-3 flex-shrink-0 bg-audifix-${account.color === 'gray' ? 'lightgray' : account.color}/20`}>
                        <Check className={`h-4 w-4 ${
                          account.color === 'purple' 
                            ? 'text-audifix-purple' 
                            : account.color === 'blue' 
                              ? 'text-audifix-blue' 
                              : 'text-white'
                        }`} />
                      </div>
                      <span className="text-gray-300">{feature}</span>
                    </div>
                  ))}
                  
                  {account.notIncluded && account.notIncluded.map((feature, i) => (
                    <div key={i} className="flex items-start text-gray-500">
                      <div className="rounded-full p-1 mr-3 flex-shrink-0 bg-audifix-lightgray/10">
                        <Check className="h-4 w-4 text-audifix-lightgray/40" />
                      </div>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
                
                <Button 
                  className={`w-full ${
                    account.color === 'purple' 
                      ? 'btn-gradient' 
                      : account.color === 'blue' 
                        ? 'bg-audifix-blue hover:bg-audifix-blue/90' 
                        : 'bg-audifix-lightgray hover:bg-audifix-lightgray/90'
                  } text-white`}
                >
                  {account.ctaText}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AccountTypes;
