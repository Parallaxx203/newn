
import { 
  Music, DollarSign, Users, Zap, Wallet, BarChart3, 
  Shield, Gift, MessageSquare 
} from "lucide-react";

const Features = () => {
  const features = [
    {
      icon: <Music className="h-6 w-6 text-audifix-purple" />,
      title: "Music Uploads",
      description: "Upload up to 25 songs to community playlist for music discovery."
    },
    {
      icon: <Zap className="h-6 w-6 text-audifix-blue" />,
      title: "AI-Powered Monetization",
      description: "Ads play before or after songs and posts, optimized for maximum revenue."
    },
    {
      icon: <Wallet className="h-6 w-6 text-audifix-purple" />,
      title: "Instant Payouts",
      description: "USDC/SOL payments to Phantom Wallet without delays or minimums."
    },
    {
      icon: <MessageSquare className="h-6 w-6 text-audifix-blue" />,
      title: "Social Tools",
      description: "Posts, stories, live video, messaging, and profile customization."
    },
    {
      icon: <Gift className="h-6 w-6 text-audifix-purple" />,
      title: "Brand Campaigns",
      description: "Creators join campaigns for sponsored ads and additional earnings."
    },
    {
      icon: <BarChart3 className="h-6 w-6 text-audifix-blue" />,
      title: "Transparent Dashboards",
      description: "Real-time analytics for creators and brands to track performance."
    },
  ];

  return (
    <section className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-gradient">Powerful Features</span> for Everyone
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Audifyx combines social media, music streaming, and blockchain technology to create
            a powerful platform for creators, brands, and listeners.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="feature-card group"
            >
              <div className="mb-4 p-3 rounded-full inline-block bg-audifix-gray border border-audifix-lightgray/50 group-hover:border-audifix-purple/50 transition-colors">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">{feature.title}</h3>
              <p className="text-gray-300">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
      
      {/* Background gradient effects */}
      <div className="absolute top-1/4 left-0 w-full h-full pointer-events-none overflow-hidden -z-10">
        <div className="absolute -top-40 -left-40 w-80 h-80 bg-audifix-purple/10 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-40 right-20 w-80 h-80 bg-audifix-blue/10 rounded-full blur-[100px]"></div>
      </div>
    </section>
  );
};

export default Features;
