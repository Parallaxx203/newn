
import { FC } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Button } from "@/components/ui/button";

interface WalletConnectButtonProps {
  className?: string;
}

const WalletConnectButton: FC<WalletConnectButtonProps> = ({ className }) => {
  const { wallet, connected } = useWallet();

  return (
    <div className={className}>
      {wallet ? (
        <WalletMultiButton className="wallet-adapter-button wallet-adapter-button-trigger btn-gradient text-white py-2 px-4 rounded-lg" />
      ) : (
        <Button variant="default" className="btn-gradient">Connect Wallet</Button>
      )}
    </div>
  );
};

export default WalletConnectButton;
