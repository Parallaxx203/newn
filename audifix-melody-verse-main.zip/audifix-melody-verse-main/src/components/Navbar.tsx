
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Music2, Menu, X, LogOut } from "lucide-react";
import WalletConnectButton from "./WalletConnectButton";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleSignUp = () => {
    navigate('/signup');
    setMobileMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
    navigate('/');
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed w-full top-0 z-50 bg-audifix-black/80 backdrop-blur-md border-b border-audifix-gray/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-audifix flex items-center justify-center">
                <Music2 className="h-4 w-4 text-white" />
              </div>
              <span className="text-white font-bold text-xl">Audifyx</span>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-300 hover:text-white transition-colors">
              Home
            </Link>
            <Link to="/creators" className="text-gray-300 hover:text-white transition-colors">
              For Creators
            </Link>
            <Link to="/brands" className="text-gray-300 hover:text-white transition-colors">
              For Brands
            </Link>
            <Link to="/about" className="text-gray-300 hover:text-white transition-colors">
              About
            </Link>
          </nav>
          
          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-3">
                <span className="text-white">Hello, {user.name.split(' ')[0]}</span>
                <Button 
                  variant="outline" 
                  size="icon"
                  className="border-audifix-purple text-white" 
                  onClick={handleLogout}
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <Button 
                variant="outline" 
                className="border-audifix-purple text-white"
                onClick={handleSignUp}
              >
                Sign Up
              </Button>
            )}
            <WalletConnectButton />
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              type="button"
              className="text-gray-300 hover:text-white"
              onClick={toggleMobileMenu}
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-audifix-black border-b border-audifix-gray/20">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link
              to="/"
              className="block px-3 py-2 text-base font-medium text-white hover:bg-audifix-lightgray/20 rounded-md"
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/creators"
              className="block px-3 py-2 text-base font-medium text-gray-300 hover:bg-audifix-lightgray/20 rounded-md"
              onClick={() => setMobileMenuOpen(false)}
            >
              For Creators
            </Link>
            <Link
              to="/brands"
              className="block px-3 py-2 text-base font-medium text-gray-300 hover:bg-audifix-lightgray/20 rounded-md"
              onClick={() => setMobileMenuOpen(false)}
            >
              For Brands
            </Link>
            <Link
              to="/about"
              className="block px-3 py-2 text-base font-medium text-gray-300 hover:bg-audifix-lightgray/20 rounded-md"
              onClick={() => setMobileMenuOpen(false)}
            >
              About
            </Link>
            <div className="flex flex-col space-y-2 pt-2">
              {user ? (
                <div className="flex items-center justify-between px-3 py-2">
                  <span className="text-white">Hello, {user.name.split(' ')[0]}</span>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="border-audifix-purple text-white"
                    onClick={handleLogout}
                  >
                    <LogOut className="h-4 w-4 mr-2" /> Logout
                  </Button>
                </div>
              ) : (
                <Button 
                  variant="outline" 
                  className="border-audifix-purple text-white w-full"
                  onClick={handleSignUp}
                >
                  Sign Up
                </Button>
              )}
              <WalletConnectButton className="w-full" />
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
