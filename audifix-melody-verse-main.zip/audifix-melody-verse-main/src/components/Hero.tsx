
import { Button } from "@/components/ui/button";
import { ArrowRight, Music, DollarSign, Users } from "lucide-react";

const Hero = () => {
  return (
    <section className="relative pt-32 pb-16 overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-radial-audifix opacity-50"></div>
      <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-audifix-black to-transparent"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center">
          {/* Hero Text */}
          <div className="lg:w-1/2 mb-12 lg:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              <span className="text-gradient">Monetize</span> Your Music <br />
              with <span className="text-gradient">Blockchain</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-xl">
              Audifyx brings creators, brands, and fans together in a blockchain-powered ecosystem 
              with instant crypto payments and AI-optimized revenue generation.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button className="btn-gradient text-white py-6 px-8 rounded-lg text-lg">
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" className="bg-transparent border-audifix-purple text-white py-6 px-8 rounded-lg text-lg">
                Learn More
              </Button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mt-12">
              <div className="text-center">
                <p className="text-audifix-purple text-3xl font-bold">$1.50</p>
                <p className="text-gray-400 text-sm">Per 1k Post Views</p>
              </div>
              <div className="text-center">
                <p className="text-audifix-blue text-3xl font-bold">$3.00</p>
                <p className="text-gray-400 text-sm">Per 1k Streams</p>
              </div>
              <div className="text-center">
                <p className="text-gradient text-3xl font-bold">Instant</p>
                <p className="text-gray-400 text-sm">USDC/SOL Payouts</p>
              </div>
            </div>
          </div>
          
          {/* Hero Visual */}
          <div className="lg:w-1/2 relative">
            <div className="relative w-full h-[500px] rounded-2xl overflow-hidden card-gradient">
              {/* Platform Preview Mockup */}
              <div className="absolute inset-0 bg-audifix-gray rounded-2xl overflow-hidden p-6 flex flex-col">
                {/* App UI Mockup */}
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-gradient-audifix flex items-center justify-center">
                      <Music className="h-4 w-4 text-white" />
                    </div>
                    <span className="text-white font-bold">Audifyx</span>
                  </div>
                  <div className="flex gap-2">
                    <div className="w-6 h-6 rounded-full bg-audifix-purple/20 flex items-center justify-center">
                      <DollarSign className="h-3 w-3 text-audifix-purple" />
                    </div>
                    <div className="w-6 h-6 rounded-full bg-audifix-blue/20 flex items-center justify-center">
                      <Users className="h-3 w-3 text-audifix-blue" />
                    </div>
                  </div>
                </div>
                
                {/* Content preview */}
                <div className="flex-1 grid grid-cols-1 gap-4">
                  <div className="bg-audifix-darkpurple/30 p-4 rounded-xl border border-audifix-purple/20">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-audifix-purple/20"></div>
                      <div>
                        <p className="text-white text-sm font-medium">Artist Name</p>
                        <p className="text-gray-400 text-xs">@artisthandle</p>
                      </div>
                    </div>
                    <div className="h-40 bg-gradient-to-br from-audifix-purple/10 to-audifix-blue/10 rounded-lg mb-3 flex items-center justify-center">
                      <Music className="h-12 w-12 text-audifix-purple/40" />
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="text-white text-sm">Track Name</div>
                      <div className="text-audifix-blue text-xs">+$0.003 / stream</div>
                    </div>
                  </div>
                  
                  <div className="bg-audifix-darkblue/30 p-4 rounded-xl border border-audifix-blue/20">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-audifix-blue/20"></div>
                      <div>
                        <p className="text-white text-sm font-medium">Brand Name</p>
                        <p className="text-gray-400 text-xs">Campaign Active</p>
                      </div>
                    </div>
                    <div className="bg-audifix-blue/10 p-2 rounded-lg">
                      <p className="text-xs text-gray-300">Funding creators with $3,000 campaign</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Glow effects */}
              <div className="absolute top-1/4 right-1/4 w-40 h-40 bg-audifix-purple/30 rounded-full blur-[80px]"></div>
              <div className="absolute bottom-1/4 left-1/4 w-40 h-40 bg-audifix-blue/30 rounded-full blur-[80px]"></div>
            </div>

            {/* Floating elements */}
            <div className="absolute -top-6 -right-6 p-4 bg-audifix-gray rounded-lg border border-audifix-purple/30 shadow-lg animate-float">
              <div className="flex items-center gap-2">
                <DollarSign className="text-audifix-purple h-4 w-4" />
                <span className="text-white text-sm">Instant Payouts</span>
              </div>
            </div>
            <div className="absolute -bottom-4 -left-4 p-4 bg-audifix-gray rounded-lg border border-audifix-blue/30 shadow-lg animate-float" style={{ animationDelay: "2s" }}>
              <div className="flex items-center gap-2">
                <Music className="text-audifix-blue h-4 w-4" />
                <span className="text-white text-sm">AI-Powered Revenue</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
