
import { Button } from "@/components/ui/button";
import { Music2, ArrowRight } from "lucide-react";

const CTA = () => {
  return (
    <section className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="relative overflow-hidden rounded-2xl bg-audifix-darkpurple/40 border border-audifix-purple/20">
          {/* Background gradients */}
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-audifix-purple/20 rounded-full blur-[80px]"></div>
          <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-audifix-blue/20 rounded-full blur-[80px]"></div>
          
          <div className="relative z-10 p-8 md:p-12 lg:p-16 flex flex-col md:flex-row items-center justify-between">
            <div className="md:max-w-xl mb-8 md:mb-0">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 rounded-full bg-gradient-audifix flex items-center justify-center mr-4 animate-pulse-glow">
                  <Music2 className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-2xl md:text-3xl font-bold text-white">Ready to transform your music career?</h3>
              </div>
              
              <p className="text-gray-300 text-lg mb-6">
                Join Audifyx today and revolutionize how you monetize your music with blockchain technology, 
                AI-powered revenue streams, and instant crypto payments.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Button className="btn-gradient text-white py-6 px-8 text-lg">
                  Get Started Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button variant="outline" className="bg-transparent border-audifix-blue text-white py-6 px-8 text-lg">
                  Contact Sales
                </Button>
              </div>
            </div>
            
            <div className="flex flex-col gap-4 md:min-w-[250px]">
              <div className="bg-audifix-black/30 p-4 rounded-xl border border-audifix-purple/30 text-center">
                <p className="text-gray-400 text-sm">For Creators</p>
                <p className="text-gradient text-2xl font-bold">$1.50 - $3.00</p>
                <p className="text-white text-sm">per 1k views/streams</p>
              </div>
              
              <div className="bg-audifix-black/30 p-4 rounded-xl border border-audifix-blue/30 text-center">
                <p className="text-gray-400 text-sm">For Brands</p>
                <p className="text-gradient text-2xl font-bold">50%</p>
                <p className="text-white text-sm">of platform fees</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;
