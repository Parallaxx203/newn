
import { DollarSign, TrendingUp, Clock, Wallet } from "lucide-react";

const MonetizationBreakdown = () => {
  const feeStructure = [
    { amount: "Under $10", fee: "$0.50 - $0.99", note: "Minimum fee is $0.50" },
    { amount: "$10 - $50", fee: "$1.00", note: "Fixed fee" },
    { amount: "$50 - $100", fee: "$2.00", note: "Fixed fee" },
    { amount: "Over $100", fee: "$3.00", note: "Maximum fee" },
  ];

  return (
    <section className="py-20 relative bg-audifix-darkpurple/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="text-gradient">Monetization</span> Breakdown
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Understand how Audifix's monetization systems work and how you can maximize your earnings.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Revenue Generation */}
          <div className="card-gradient rounded-xl p-8">
            <h3 className="text-2xl font-bold mb-6 flex items-center">
              <TrendingUp className="mr-2 h-6 w-6 text-audifix-purple" />
              Revenue Generation
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-audifix-black/30 p-4 rounded-lg border border-audifix-purple/20">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-400">Posts</span>
                  <DollarSign className="h-4 w-4 text-audifix-purple" />
                </div>
                <p className="text-2xl font-bold text-white">$1.50</p>
                <p className="text-sm text-gray-400">per 1,000 views</p>
              </div>
              
              <div className="bg-audifix-black/30 p-4 rounded-lg border border-audifix-blue/20">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-400">Music</span>
                  <DollarSign className="h-4 w-4 text-audifix-blue" />
                </div>
                <p className="text-2xl font-bold text-white">$3.00</p>
                <p className="text-sm text-gray-400">per 1,000 streams</p>
              </div>
              
              <div className="bg-audifix-black/30 p-4 rounded-lg border border-audifix-purple/20">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-400">Payouts</span>
                  <Clock className="h-4 w-4 text-gradient" />
                </div>
                <p className="text-2xl font-bold text-gradient">Instant</p>
                <p className="text-sm text-gray-400">USDC/SOL transfers</p>
              </div>
            </div>
            
            <h4 className="text-xl font-semibold mb-4">How Ads Work</h4>
            
            <div className="space-y-6">
              <div className="bg-audifix-black/20 p-4 rounded-lg">
                <h5 className="font-semibold mb-2 text-white">For Posts</h5>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex">
                    <span className="inline-block w-2 h-2 rounded-full bg-audifix-purple mt-2 mr-2 flex-shrink-0"></span>
                    Short 3–6 second ads appear before or after content
                  </li>
                  <li className="flex">
                    <span className="inline-block w-2 h-2 rounded-full bg-audifix-purple mt-2 mr-2 flex-shrink-0"></span>
                    AI determines optimal ad placement based on engagement
                  </li>
                  <li className="flex">
                    <span className="inline-block w-2 h-2 rounded-full bg-audifix-purple mt-2 mr-2 flex-shrink-0"></span>
                    Earnings: $1.50 per 1,000 views
                  </li>
                </ul>
              </div>
              
              <div className="bg-audifix-black/20 p-4 rounded-lg">
                <h5 className="font-semibold mb-2 text-white">For Music</h5>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex">
                    <span className="inline-block w-2 h-2 rounded-full bg-audifix-blue mt-2 mr-2 flex-shrink-0"></span>
                    Ads play before or after tracks to enhance engagement
                  </li>
                  <li className="flex">
                    <span className="inline-block w-2 h-2 rounded-full bg-audifix-blue mt-2 mr-2 flex-shrink-0"></span>
                    Creators join brand campaigns for additional revenue
                  </li>
                  <li className="flex">
                    <span className="inline-block w-2 h-2 rounded-full bg-audifix-blue mt-2 mr-2 flex-shrink-0"></span>
                    Earnings: $3.00 per 1,000 streams
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          {/* Withdrawal System */}
          <div className="card-gradient rounded-xl p-8">
            <h3 className="text-2xl font-bold mb-6 flex items-center">
              <Wallet className="mr-2 h-6 w-6 text-audifix-blue" />
              Withdrawal System
            </h3>
            
            <div className="mb-8">
              <div className="bg-audifix-black/30 p-4 rounded-lg border border-audifix-blue/20 mb-6">
                <h4 className="text-lg font-semibold mb-2">Brand Campaign Funding</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-400 text-sm mb-1">Minimum Funding Requirement</p>
                    <p className="text-white font-semibold">$3,000 via Phantom or Jupiter</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm mb-1">Process</p>
                    <p className="text-white">Fund Rewards Wallet to launch campaigns</p>
                  </div>
                </div>
              </div>
              
              <p className="text-gray-300 mb-4">
                Withdrawals process instantly in USDC/SOL via Phantom Wallet with a simple fee structure.
              </p>
            </div>
            
            <h4 className="text-xl font-semibold mb-4">Withdrawal Fees</h4>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-audifix-lightgray/30">
                    <th className="text-left py-3 text-gray-300">Withdrawal Amount</th>
                    <th className="text-left py-3 text-gray-300">Fee</th>
                    <th className="text-left py-3 text-gray-300">Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {feeStructure.map((row, index) => (
                    <tr 
                      key={index} 
                      className={`border-b border-audifix-lightgray/10 ${
                        index % 2 === 0 ? 'bg-audifix-black/10' : ''
                      }`}
                    >
                      <td className="py-3 text-white">{row.amount}</td>
                      <td className="py-3 text-white">{row.fee}</td>
                      <td className="py-3 text-gray-400">{row.note}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="mt-8 p-4 bg-audifix-black/30 rounded-lg border border-audifix-purple/20">
              <h4 className="text-lg font-semibold mb-2">Revenue Distribution Model</h4>
              <ul className="space-y-2 text-gray-300">
                <li className="flex">
                  <span className="inline-block w-2 h-2 rounded-full bg-gradient-audifix mt-2 mr-2 flex-shrink-0"></span>
                  Audifix earns revenue from platform fees, not creator payments
                </li>
                <li className="flex">
                  <span className="inline-block w-2 h-2 rounded-full bg-gradient-audifix mt-2 mr-2 flex-shrink-0"></span>
                  50% of all platform fees go to Audifix, 50% to brands funding ad campaigns
                </li>
                <li className="flex">
                  <span className="inline-block w-2 h-2 rounded-full bg-gradient-audifix mt-2 mr-2 flex-shrink-0"></span>
                  Creators are paid directly by brands who advertise on their content
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      {/* Background gradient effects */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden -z-10">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-audifix-purple/10 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-40 left-20 w-80 h-80 bg-audifix-blue/10 rounded-full blur-[100px]"></div>
      </div>
    </section>
  );
};

export default MonetizationBreakdown;
